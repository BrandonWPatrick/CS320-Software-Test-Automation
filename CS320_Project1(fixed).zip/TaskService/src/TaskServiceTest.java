import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskStoresById() {
        TaskService service = new TaskService();
        service.addTask(new Task("T1", "Name", "Desc"));
        assertNotNull(service.getTask("T1"));
    }

    @Test
    void testAddTaskRequiresUniqueId() {
        TaskService service = new TaskService();
        service.addTask(new Task("T1", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () ->
                service.addTask(new Task("T1", "Other", "Other desc")));
    }

    @Test
    void testDeleteTaskById() {
        TaskService service = new TaskService();
        service.addTask(new Task("T1", "Name", "Desc"));
        service.deleteTask("T1");
        assertNull(service.getTask("T1"));
    }

    @Test
    void testUpdateFieldsById() {
        TaskService service = new TaskService();
        service.addTask(new Task("T1", "Name", "Desc"));

        service.updateName("T1", "Updated");
        service.updateDescription("T1", "Updated description");

        assertEquals("Updated", service.getTask("T1").getName());
        assertEquals("Updated description", service.getTask("T1").getDescription());
    }

    @Test
    void testUpdateMissingTaskThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateName("missing", "Name"));
    }

    @Test
    void testUpdateValidatesNewValues() {
        TaskService service = new TaskService();
        service.addTask(new Task("T1", "Name", "Desc"));

        assertThrows(IllegalArgumentException.class, () -> service.updateName("T1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("T1", null));
    }
}
