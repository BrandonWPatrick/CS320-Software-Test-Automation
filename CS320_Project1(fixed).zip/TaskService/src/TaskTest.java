import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreatesWithValidFields() {
        Task t = new Task("T1", "Do laundry", "Wash and dry clothes");
        assertEquals("T1", t.getTaskId());
        assertEquals("Do laundry", t.getName());
        assertEquals("Wash and dry clothes", t.getDescription());
    }

    @Test
    void testTaskIdValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("", "Name", "Desc"));
    }

    @Test
    void testNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task("T1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("T1", "012345678901234567890", "Desc")); // 21 chars
    }

    @Test
    void testDescriptionValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task("T1", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("T1", "Name",
                "012345678901234567890123456789012345678901234567890")); // 51 chars
    }

    @Test
    void testUpdatableFieldsStillValidated() {
        Task t = new Task("T1", "Name", "Desc");
        t.setName("New Name");
        t.setDescription("New description");
        assertEquals("New Name", t.getName());
        assertEquals("New description", t.getDescription());

        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
    }
}
