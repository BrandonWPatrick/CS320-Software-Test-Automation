import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID must be unique");
        }
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        Task t = getRequired(taskId);
        t.setName(name);
    }

    public void updateDescription(String taskId, String description) {
        Task t = getRequired(taskId);
        t.setDescription(description);
    }

    public Task getTask(String taskId) {
        if (taskId == null) return null;
        return tasks.get(taskId);
    }

    private Task getRequired(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        Task t = tasks.get(taskId);
        if (t == null) {
            throw new IllegalArgumentException("Task not found");
        }
        return t;
    }
}
