import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointmentStoresById() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment(new Appointment("A1", future, "Visit"));
        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    void testAddRequiresUniqueId() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment(new Appointment("A1", future, "Visit"));

        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(new Appointment("A1", future, "Other")));
    }

    @Test
    void testDeleteById() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment(new Appointment("A1", future, "Visit"));
        service.deleteAppointment("A1");

        assertNull(service.getAppointment("A1"));
    }
}
