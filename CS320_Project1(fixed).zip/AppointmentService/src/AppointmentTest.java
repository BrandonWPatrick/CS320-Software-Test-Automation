import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointmentCreates() {
        Date future = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("A1", future, "Checkup");

        assertEquals("A1", a.getAppointmentId());
        assertEquals("Checkup", a.getDescription());
        assertEquals(future, a.getAppointmentDate());
    }

    @Test
    void testAppointmentIdValidation() {
        Date future = new Date(System.currentTimeMillis() + 100000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, future, "Desc"));

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", future, "Desc"));
    }

    @Test
    void testDateValidation() {
        Date past = new Date(System.currentTimeMillis() - 100000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", null, "Desc"));

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", past, "Desc"));
    }

    @Test
    void testDescriptionValidation() {
        Date future = new Date(System.currentTimeMillis() + 100000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", future, null));

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", future,
                        "012345678901234567890123456789012345678901234567890")); // 51
    }
}
