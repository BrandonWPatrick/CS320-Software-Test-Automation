// ContactTest.java
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testContactCreatesWithValidFields() {
        Contact c = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("123", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void testContactIdNotNullNotTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("", "A", "B", "1234567890", "Addr"));
    }

    @Test
    void testFirstNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", null, "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "01234567890", "B", "1234567890", "Addr"));
    }

    @Test
    void testLastNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", null, "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "01234567890", "1234567890", "Addr"));
    }

    @Test
    void testPhoneValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", null, "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "123", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "12345678901", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "abcdefghij", "Addr"));
    }

    @Test
    void testAddressValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "1234567890", "0123456789012345678901234567890"));
    }

    @Test
    void testUpdatableFieldsStillValidated() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Main");
        c.setFirstName("Jane");
        c.setLastName("Smith");
        c.setPhone("0987654321");
        c.setAddress("456 Other St");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Other St", c.getAddress());

        assertThrows(IllegalArgumentException.class, () -> c.setPhone("999"));
    }
}
