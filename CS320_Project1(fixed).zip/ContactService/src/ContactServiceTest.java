// ContactServiceTest.java
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void testAddContactStoresById() {
        ContactService service = new ContactService();
        Contact c = new Contact("A1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(c);
        assertNotNull(service.getContact("A1"));
        assertEquals("John", service.getContact("A1").getFirstName());
    }

    @Test
    void testAddContactRequiresUniqueId() {
        ContactService service = new ContactService();
        service.addContact(new Contact("A1", "John", "Doe", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(new Contact("A1", "Jane", "Smith", "0987654321", "456 Other"))
        );
    }

    @Test
    void testDeleteContactById() {
        ContactService service = new ContactService();
        service.addContact(new Contact("A1", "John", "Doe", "1234567890", "123 Main St"));
        service.deleteContact("A1");
        assertNull(service.getContact("A1"));
    }

    @Test
    void testUpdateFieldsById() {
        ContactService service = new ContactService();
        service.addContact(new Contact("A1", "John", "Doe", "1234567890", "123 Main St"));

        service.updateFirstName("A1", "Jane");
        service.updateLastName("A1", "Smith");
        service.updatePhone("A1", "0987654321");
        service.updateAddress("A1", "456 Other St");

        Contact updated = service.getContact("A1");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Other St", updated.getAddress());
    }

    @Test
    void testUpdateMissingContactThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("missing", "John"));
    }

    @Test
    void testUpdateValidatesNewValues() {
        ContactService service = new ContactService();
        service.addContact(new Contact("A1", "John", "Doe", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("A1", "123"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("A1", "0123456789012345678901234567890"));
    }
}
